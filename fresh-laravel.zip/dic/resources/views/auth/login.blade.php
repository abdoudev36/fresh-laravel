@extends('layouts.auth')
@section('title') Login @endsection

@section('body')
	<h1>Login</h1>
@endsection