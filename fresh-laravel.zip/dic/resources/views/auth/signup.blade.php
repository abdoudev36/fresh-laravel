@extends('layouts.auth')
@section('title') Signup @endsection

@section('body')
	<h1>Signup</h1>
@endsection