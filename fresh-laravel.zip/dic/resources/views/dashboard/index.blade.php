@extends('layouts.dashboard')
@section('title') Dashboard @endsection

@section('body')
	<h1>dashboard</h1>
@endsection