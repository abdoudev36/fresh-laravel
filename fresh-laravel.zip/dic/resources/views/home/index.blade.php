@extends('layouts.layout')
@section('title') Abdou Dev @endsection

@section('body')
	<h1>home</h1>
@endsection