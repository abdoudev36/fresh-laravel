<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>@yield('title')</title>
	<link rel="stylesheet" type="text/css" href="{{ asset('/home/css/bootstrap.min.css') }}">
	<link rel="stylesheet" type="text/css" href="{{ asset('/auth/css/app.css') }}">
</head>
<body>
	@yield('body')
	<script src="{{ asset('/home/js/bootstrap.bundle.min.js') }}"></script>
	<script src="{{ asset('/auth/js/app.js') }}"></script>
</body>
</html>